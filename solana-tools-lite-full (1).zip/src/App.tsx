import React, { useCallback, useMemo, useState, useEffect, createContext, useContext } from "react";
import * as web3 from "@solana/web3.js";
import { WalletAdapterNetwork } from "@solana/wallet-adapter-base";
import { ConnectionProvider, WalletProvider, useWallet } from "@solana/wallet-adapter-react";
import { WalletModalProvider, WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { PhantomWalletAdapter, SolflareWalletAdapter, BackpackWalletAdapter, LedgerWalletAdapter } from "@solana/wallet-adapter-wallets";
// ✅ Single namespace import from SPL-Token avoids ESM/CJS interop issues
import * as splToken from "@solana/spl-token";
import "@solana/wallet-adapter-react-ui/styles.css";

// ==== Feature flags (avoid bundling optional SDKs in sandbox) ====
// If you want OpenBook / Raydium features active, set these to true *and* install their SDKs.
const FEATURES = {
  openbook: false, // requires: @openbook-dex/openbook
  raydium: false,  // requires: @raydium-io/raydium-sdk
};

// ===== Mini UI shims =====
// (icons) replaced external 'lucide-react' with light emoji components to avoid missing dependency
const Icon = ({ children, className = "" }: any) => <span className={className} aria-hidden>{children}</span>;
const Loader2   = (p:any) => <Icon {...p}>⏳</Icon>;
const ShieldAlert = (p:any) => <Icon {...p}>🛡️</Icon>;
const Wrench    = (p:any) => <Icon {...p}>🔧</Icon>;
const Undo2     = (p:any) => <Icon {...p}>↩️</Icon>;
const XCircle   = (p:any) => <Icon {...p}>✖️</Icon>;
const Coins     = (p:any) => <Icon {...p}>🪙</Icon>;
const ServerCog = (p:any) => <Icon {...p}>⚙️</Icon>;
const KeyRound  = (p:any) => <Icon {...p}>🔑</Icon>;
const Snowflake = (p:any) => <Icon {...p}>❄️</Icon>;
const Lock      = (p:any) => <Icon {...p}>🔒</Icon>;
const Unlock    = (p:any) => <Icon {...p}>🔓</Icon>;
const Upload    = (p:any) => <Icon {...p}>📤</Icon>;
const Button = (props: any) => <button {...props} className={("rounded-xl px-3 py-2 text-sm bg-white/10 hover:bg-white/20 border border-white/10 "+(props.className||""))} />
const Card = (props: any) => <div {...props} className={("rounded-2xl border border-white/10 bg-black/20 p-0 "+(props.className||""))} />
const CardHeader = ({children, className=""}: any) => <div className={"p-4 "+className}>{children}</div>
const CardTitle = ({children, className=""}: any) => <h3 className={"text-lg font-semibold "+className}>{children}</h3>
const CardDescription = ({children, className=""}: any) => <p className={"text-xs text-neutral-400 "+className}>{children}</p>
const CardContent = ({children, className=""}: any) => <div className={"p-4 pt-0 "+className}>{children}</div>
const CardFooter = ({children, className=""}: any) => <div className={"p-4 border-t border-white/10 "+className}>{children}</div>
const Input = (props: any) => <input {...props} className={("w-full rounded-xl bg-black/30 border border-white/10 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-white/20 "+(props.className||""))} />
const Label = (props: any) => <label {...props} className={("text-xs text-neutral-400 "+(props.className||""))} />

// ===== Helpers + tiny dev tests =====
export function formatToast(title: string, description?: string) {
  return `${title}${description ? "\n" + description : ""}`;
}

export function splitLines(text: string): string[] {
  // robust across CRLF/LF, trimmed, no blank lines
  return text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
}

export function hasExtraFraction(ui: string, decimals: number): boolean {
  const cleaned = ui.replace(/,/g, "").trim();
  if (!/^\d*(?:\.\d*)?$/.test(cleaned)) return false; // invalid will be handled elsewhere
  const [, frac = ""] = cleaned.split(".");
  return frac.length > Math.max(0, decimals);
}

export function toBaseUnits(ui: string, decimals: number): bigint {
  const cleaned = ui.replace(/,/g, "").trim();
  if (!/^\d*(?:\.\d*)?$/.test(cleaned)) throw new Error("Invalid number");
  const [intPart = "", fracPartRaw = ""] = cleaned.split(".");
  const fracPart = (fracPartRaw + "0".repeat(decimals)).slice(0, decimals);
  const full = (intPart || "0") + fracPart; // no dot
  return BigInt(full || "0");
}

export function baseUnitsToNumberSafe(amount: bigint): number {
  const max = BigInt(Number.MAX_SAFE_INTEGER);
  if (amount > max) throw new Error("Amount too large for JS number");
  return Number(amount);
}

function pow10(n: number): bigint { let r = 1n; for (let i=0;i<n;i++) r *= 10n; return r; }
export function formatBaseToUiString(base: bigint, decimals: number): string {
  const sign = base < 0n ? "-" : "";
  let x = base < 0n ? -base : base;
  const scale = pow10(decimals);
  const intPart = x / scale;
  let fracPart = (x % scale).toString().padStart(decimals, '0');
  if (decimals > 0) fracPart = fracPart.replace(/0+$/, '');
  return sign + intPart.toString() + (decimals > 0 && fracPart ? '.' + fracPart : (decimals > 0 ? '.0' : ''));
}

// microLamports/CU -> lamports (1e6 microLamports = 1 lamport)
export function calcPriorityFeeLamports(cu: number, priceMicro: number): bigint {
  return (BigInt(Math.max(0, cu)) * BigInt(Math.max(0, priceMicro))) / 1000000n;
}

// small utils: function declaration avoids TSX generic/JSX parsing issues
function chunked<T>(arr: T[], size: number): T[][] {
  if (size <= 0) throw new Error("chunk size must be > 0");
  return Array.from({ length: Math.ceil(arr.length / size) }, (_, i) => arr.slice(i * size, (i + 1) * size));
}

function withPriority(tx: web3.Transaction, units = 1000000, microLamports = 2000) {
  const CBP: any = (web3 as any).ComputeBudgetProgram;
  if (!CBP || typeof CBP.setComputeUnitLimit !== "function" || typeof CBP.setComputeUnitPrice !== "function") {
    return tx;
  }
  return tx
    .add(CBP.setComputeUnitLimit({ units }))
    .add(CBP.setComputeUnitPrice({ microLamports }));
}

const useToast = () => ({
  toast: ({ title, description }: { title: string; description?: string }) => {
    if (typeof window !== "undefined") alert(formatToast(title, description));
  }
});

function useConn(rpcUrl?: string, network: WalletAdapterNetwork = WalletAdapterNetwork.Mainnet) {
  const endpoint = useMemo(() => rpcUrl || web3.clusterApiUrl(network as any), [rpcUrl, network]);
  const conn = useMemo(() => new web3.Connection(endpoint, { commitment: "confirmed" }), [endpoint]);
  return { conn, endpoint };
}

// --- Mint info detection without relying on splToken.getMint (works across versions) ---
async function detectMintInfoViaRPC(conn: web3.Connection, mintPk: web3.PublicKey): Promise<{decimals: number, mintAuthority: string | null, freezeAuthority: string | null}> {
  const acc = await conn.getParsedAccountInfo(mintPk);
  const v: any = acc.value;
  if (!v || !v.data || !v.data.parsed) throw new Error("Account not found or not a parsed token mint");
  const parsed = v.data.parsed;
  if (parsed.type !== "mint") throw new Error("Account is not a token mint");
  const info = parsed.info || {};
  return {
    decimals: Number(info.decimals ?? 0),
    mintAuthority: info.mintAuthority ?? null,
    freezeAuthority: info.freezeAuthority ?? null,
  };
}

// Dev-time self-checks (non-blocking)
if (typeof window !== "undefined") {
  console.assert(formatToast("T") === "T", "formatToast: title only");
  console.assert(formatToast("T", "D") === "T\\nD", "formatToast: with desc");
  console.assert(toBaseUnits("1", 9) === 1000000000n, "toBaseUnits 1e9");
  console.assert(toBaseUnits("0.000000001", 9) === 1n, "toBaseUnits nano");
  console.assert(toBaseUnits("0", 0) === 0n, "toBaseUnits zero decimals");
  console.assert(toBaseUnits("123.450", 3) === 123450n, "toBaseUnits trim zeros");
  console.assert(toBaseUnits("999999.999", 3) === 999999999n, "toBaseUnits large");
  try { baseUnitsToNumberSafe(9007199254740991n); } catch { console.assert(false, "safe max"); }
  let threw = false; try { baseUnitsToNumberSafe(9007199254740992n); } catch { threw = true; } finally { console.assert(threw, "throws on overflow"); }
  console.assert(calcPriorityFeeLamports(300000, 2000) === 600n, "priority calc basic");
  console.assert(calcPriorityFeeLamports(1000000, 1000000) === 1000000n, "priority calc 1e6");
  console.assert(calcPriorityFeeLamports(1234567, 89000) === 109876n, "priority calc big");
  console.assert(calcPriorityFeeLamports(0, 2000) === 0n, "priority calc zero CU");
  console.assert(JSON.stringify(chunked([1,2,3,4,5], 2)) === JSON.stringify([[1,2],[3,4],[5]]), "chunked works");
  let bad = false; try { toBaseUnits("abc", 9); } catch { bad = true; } finally { console.assert(bad, "rejects non-numeric input"); }
  bad = false; try { chunked([1,2,3], 0); } catch { bad = true; } finally { console.assert(bad, "chunked rejects size<=0"); }
  console.assert(toBaseUnits("0.1", 2) === 10n, "toBaseUnits tenths");
  console.assert(toBaseUnits("2.", 2) === 200n, "toBaseUnits trailing dot");
  console.assert(toBaseUnits("1.2345", 2) === 123n, "toBaseUnits truncates extra fraction");
  console.assert(hasExtraFraction("1.2345", 2) === true, "hasExtraFraction detects overflow fraction");
  console.assert(hasExtraFraction("1.001", 2) === true, "hasExtraFraction detects 3>2");
  console.assert(JSON.stringify(splitLines("a\\nb\\n")) === JSON.stringify(["a","b"]), "splitLines LF");
  console.assert(JSON.stringify(splitLines("a\\r\\nb\\r\\n")) === JSON.stringify(["a","b"]), "splitLines CRLF");
  console.assert(formatBaseToUiString(0n, 9) === "0.0", "format zero");
  console.assert(formatBaseToUiString(1n, 9) === "0.000000001", "format 1 lamport");
  console.assert(formatBaseToUiString(1000000000n, 9) === "1", "format 1 base unit");
  console.assert(formatBaseToUiString(1234500000n, 9) === "1.2345", "format trims trailing zeros");
  // Additional validator tests for aggregation logic (pure approximation)
  const aggSum = (pairs: [string,string][], d=2) => pairs.reduce((m,[a,ui]) => { const b = toBaseUnits(ui,d); m.set(a,(m.get(a)||0n)+b); return m; }, new Map<string,bigint>());
  const m = aggSum([["A1","1.2"],["A2","3"],["A1","0.3"]], 1); // decimals=1
  console.assert(m.get("A1")===15n && m.get("A2")===30n, "aggregate example");
}

function BroomIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-foreground">
      <path d="M3 21l6-6m0 0l3 3m-3-3l3-3m8-8l-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// ===== Token Config =====
const TOKEN_STORAGE_KEY = "kidwiftools.tokenConfig";

type TokenConfig = { mint: string; decimals: number; symbol: string; keepAuthorities: boolean };

type TokenConfigState = { config: TokenConfig; setConfig: React.Dispatch<React.SetStateAction<TokenConfig>> };

const defaultTokenConfig: TokenConfig = { mint: "", decimals: 9, symbol: "KID$", keepAuthorities: true };

const TokenConfigContext = createContext<TokenConfigState>({
  config: defaultTokenConfig,
  // @ts-expect-error init
  setConfig: () => {}
});

function TokenConfigProvider({ children }: { children: React.ReactNode }) {
  const [config, setConfig] = useState<TokenConfig>(() => {
    if (typeof window !== "undefined") {
      try {
        const raw = localStorage.getItem(TOKEN_STORAGE_KEY);
        return raw ? JSON.parse(raw) : defaultTokenConfig;
      } catch {}
    }
    return defaultTokenConfig;
  });
  useEffect(() => {
    try { localStorage.setItem(TOKEN_STORAGE_KEY, JSON.stringify(config)); } catch {}
  }, [config]);
  return <TokenConfigContext.Provider value={{ config, setConfig }}>{children}</TokenConfigContext.Provider>;
}

function useTokenConfig(){ return useContext(TokenConfigContext); }

function TokenSettingsCard() {
  const { config, setConfig } = useTokenConfig();
  const { toast } = useToast();
  const { conn } = useConn();
  const [mint, setMint] = useState(config.mint);
  const [decimals, setDecimals] = useState<number>(config.decimals);
  const [symbol, setSymbol] = useState<string>(config.symbol);
  const [keepAuth, setKeepAuth] = useState<boolean>(config.keepAuthorities);
  const [busy, setBusy] = useState(false);

  const onDetect = useCallback(async () => {
    try {
      setBusy(true);
      const mintPk = new web3.PublicKey(mint);
      // ✅ Robust across spl-token versions
      const mi = await detectMintInfoViaRPC(conn, mintPk);
      setDecimals(mi.decimals);
      const mintAuth = mi.mintAuthority || "null";
      const freezeAuth = mi.freezeAuthority || "null";
      toast({ title: "Detected token", description: `decimals=${mi.decimals}\nMintAuth=${mintAuth}\nFreezeAuth=${freezeAuth}` });
    } catch (e:any) {
      toast({ title: "Detect failed", description: String(e) });
    } finally { setBusy(false); }
  }, [mint, conn]);

  const onSave = useCallback(() => {
    try {
      if (mint) { new web3.PublicKey(mint); }
      setConfig({ mint, decimals, symbol: symbol || "KID$", keepAuthorities: keepAuth });
      toast({ title: "Token config saved", description: `${symbol || "KID$"} • ${mint || "(none)"}` });
    } catch (e:any) {
      toast({ title: "Save failed", description: String(e) });
    }
  }, [mint, decimals, symbol, keepAuth, setConfig]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Wrench className="h-5 w-5"/>Token Settings</CardTitle>
        <CardDescription>Prefill Kid$ Wif Tools with your token.</CardDescription>
      </CardHeader>
      <CardContent className="grid gap-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-2">
            <Label>Mint Address</Label>
            <Input value={mint} onChange={(e)=>setMint(e.target.value)} placeholder="Paste your mint address" />
          </div>
          <div>
            <Label>Symbol</Label>
            <Input value={symbol} onChange={(e)=>setSymbol(e.target.value)} placeholder="KID$" />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div>
            <Label>Decimals</Label>
            <Input type="number" value={decimals} onChange={(e)=>setDecimals(parseInt(e.target.value||"0"))} />
          </div>
          <div className="md:col-span-2 flex items-center gap-2 mt-6">
            <input type="checkbox" checked={keepAuth} onChange={(e)=>setKeepAuth(e.target.checked)} />
            <Label>Keep authorities after setup (uncheck to plan renounce)</Label>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex gap-2">
        <Button onClick={onDetect} disabled={busy || !mint}>{busy? <Loader2 className="mr-2 h-4 w-4 animate-spin"/>:<ServerCog className="mr-2 h-4 w-4"/>}Detect</Button>
        <Button onClick={onSave}><Wrench className="mr-2 h-4 w-4"/>Save</Button>
      </CardFooter>
    </Card>
  );
}

// ===== Tools =====
function MintBurnTool({ conn }: { conn: web3.Connection }) {
  const wallet = useWallet();
  const { config } = useTokenConfig();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [mintStr, setMintStr] = useState(config.mint || "");
  const [destStr, setDestStr] = useState("");
  const [amountUi, setAmountUi] = useState(0);
  const [decimals, setDecimals] = useState<number>(config.decimals || 9);
  const [mode, setMode] = useState<"mint"|"burn">("mint");

  useEffect(()=>{ if(config.mint) setMintStr(config.mint); if(config.decimals!=null) setDecimals(config.decimals); },[config]);

  const onRun = useCallback(async () => {
    if (!wallet.publicKey || !wallet.signTransaction) { toast({ title: "Connect a wallet" }); return; }
    try {
      setBusy(true);
      const mint = new web3.PublicKey(mintStr);
      const uiStr = String(amountUi);
      if (hasExtraFraction(uiStr, decimals)) {
        toast({ title: "Too many decimal places", description: `Token supports ${decimals} decimals; your input has more. Fix the amount.` });
        setBusy(false);
        return;
      }
      const amountBig = toBaseUnits(uiStr, decimals); // bigint for precision
      const amount = baseUnitsToNumberSafe(amountBig); // pass number to *Checked APIs
      const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash();
      const tx = withPriority(new web3.Transaction({ feePayer: wallet.publicKey!, blockhash, lastValidBlockHeight }));

      if (mode === "mint") {
        const owner = new web3.PublicKey(destStr || wallet.publicKey!.toBase58());
        const ata = await splToken.getAssociatedTokenAddress(mint, owner, false);
        const info = await conn.getAccountInfo(ata);
        if (!info) {
          tx.add(splToken.createAssociatedTokenAccountInstruction(wallet.publicKey!, ata, owner, mint));
        }
        tx.add(splToken.createMintToCheckedInstruction(mint, ata, wallet.publicKey!, amount, decimals));
      } else {
        const owner = wallet.publicKey!;
        const ata = await splToken.getAssociatedTokenAddress(mint, owner, false);
        tx.add(splToken.createBurnCheckedInstruction(ata, mint, owner, amount, decimals));
      }

      const signed = await wallet.signTransaction(tx);
      const sig = await conn.sendRawTransaction(signed.serialize());
      await conn.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, "confirmed");
      toast({ title: mode === "mint" ? "Minted tokens" : "Burned tokens", description: `Tx: ${sig}` });
    } catch (e:any) {
      toast({ title: "Mint/Burn failed", description: String(e) });
    } finally { setBusy(false); }
  }, [wallet.publicKey, wallet.signTransaction, conn, mintStr, destStr, amountUi, decimals, mode]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Wrench className="h-5 w-5"/>Mint & Burn (Admin)</CardTitle>
        <CardDescription>Use with care. Requires mint authority for minting.</CardDescription>
      </CardHeader>
      <CardContent className="grid gap-3">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <Label>Mint</Label>
            <Input value={mintStr} onChange={e=>setMintStr(e.target.value)} />
          </div>
          <div>
            <Label>Mode</Label>
            <div className="flex gap-2 mt-2">
              <Button onClick={()=>setMode("mint")} className={mode==="mint"?"bg-white/20":""}>Mint</Button>
              <Button onClick={()=>setMode("burn")} className={mode==="burn"?"bg-white/20":""}>Burn</Button>
            </div>
          </div>
        </div>
        {mode === "mint" && (
          <div>
            <Label>Destination Owner (optional, defaults to your wallet)</Label>
            <Input value={destStr} onChange={e=>setDestStr(e.target.value)} />
          </div>
        )}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Amount (UI units)</Label>
            <Input type="number" value={amountUi} onChange={e=>setAmountUi(parseFloat(e.target.value||"0"))} />
          </div>
          <div>
            <Label>Decimals</Label>
            <Input type="number" value={decimals} onChange={e=>setDecimals(parseInt(e.target.value||"0"))} />
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={onRun} disabled={busy || !mintStr || amountUi<=0}>
          {busy? <Loader2 className="mr-2 h-4 w-4 animate-spin"/>:<Wrench className="mr-2 h-4 w-4"/>}
          {mode==="mint"?"Mint Tokens":"Burn Tokens"}
        </Button>
      </CardFooter>
    </Card>
  );
}

function WSOLUnwrapper({ conn }: { conn: web3.Connection }) {
  const wallet = useWallet();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const onUnwrap = useCallback(async () => {
    if (!wallet.publicKey || !wallet.signTransaction) { toast({ title: "Connect a wallet" }); return; }
    setBusy(true);
    try {
      const ata = await splToken.getAssociatedTokenAddress(splToken.NATIVE_MINT, wallet.publicKey, false);
      const info = await conn.getAccountInfo(ata);
      if (!info) { toast({ title: "No WSOL account" }); setBusy(false); return; }
      const ix = splToken.createCloseAccountInstruction(ata, wallet.publicKey, wallet.publicKey);
      const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash();
      const tx = withPriority(new web3.Transaction({ feePayer: wallet.publicKey, blockhash, lastValidBlockHeight }).add(ix));
      const signed = await wallet.signTransaction(tx);
      const sig = await conn.sendRawTransaction(signed.serialize());
      await conn.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, "confirmed");
      toast({ title: "WSOL unwrapped", description: `Tx: ${sig}` });
    } catch (e:any) {
      toast({ title: "Unwrap failed", description: String(e) });
    } finally { setBusy(false); }
  }, [wallet.publicKey, wallet.signTransaction, conn]);
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Undo2 className="h-5 w-5" />Unwrap WSOL</CardTitle>
        <CardDescription>Close WSOL account to reclaim SOL.</CardDescription>
      </CardHeader>
      <CardContent className="text-sm text-neutral-400">Detects your WSOL ATA and sends closeAccount.</CardContent>
      <CardFooter>
        <Button onClick={onUnwrap} disabled={busy}>{busy ? (<Loader2 className="mr-2 h-4 w-4 animate-spin" />) : (<Undo2 className="mr-2 h-4 w-4" />)}Unwrap</Button>
      </CardFooter>
    </Card>
  );
}

function RevokeDelegates({ conn }: { conn: web3.Connection }) {
  const wallet = useWallet();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const onRevoke = useCallback(async () => {
    if (!wallet.publicKey || !wallet.signTransaction) { toast({ title: "Connect a wallet" }); return; }
    setBusy(true);
    try {
      const prog = new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");
      const resp = await conn.getParsedTokenAccountsByOwner(wallet.publicKey, { programId: prog });
      const ixs = resp.value
        .map(({ pubkey, account }) => ({ pubkey, info: (account as any).data.parsed.info }))
        .filter(({ info }) => info.delegate)
        .map(({ pubkey }) => splToken.createRevokeInstruction(pubkey, wallet.publicKey!));
      if (!ixs.length) { toast({ title: "No delegates found" }); setBusy(false); return; }

      for (const chunk of chunked(ixs, 8)) {
        const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash();
        const tx = withPriority(new web3.Transaction({ feePayer: wallet.publicKey!, blockhash, lastValidBlockHeight }));
        chunk.forEach((ix) => tx.add(ix));
        const signed = await wallet.signTransaction(tx);
        const sig = await conn.sendRawTransaction(signed.serialize());
        await conn.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, "confirmed");
      }

      toast({ title: "Delegates revoked", description: `Processed ${ixs.length}` });
    } catch (e:any) {
      toast({ title: "Revoke failed", description: String(e) });
    } finally { setBusy(false); }
  }, [conn, wallet.publicKey, wallet.signTransaction]);
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><ShieldAlert className="h-5 w-5" />Revoke Token Delegates</CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-neutral-400">Scans your SPL accounts and revokes any delegate.</CardContent>
      <CardFooter>
        <Button onClick={onRevoke} disabled={busy}>{busy ? (<Loader2 className="mr-2 h-4 w-4 animate-spin" />) : (<KeyRound className="mr-2 h-4 w-4" />)}Revoke All</Button>
      </CardFooter>
    </Card>
  );
}

function CloseEmptyTokenAccounts({ conn }: { conn: web3.Connection }) {
  const wallet = useWallet();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [closed, setClosed] = useState<number | null>(null);
  const onClose = useCallback(async () => {
    if (!wallet.publicKey || !wallet.signTransaction) { toast({ title: "Connect a wallet" }); return; }
    setBusy(true);
    try {
      const prog = new web3.PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");
      const resp = await conn.getParsedTokenAccountsByOwner(wallet.publicKey, { programId: prog });
      const empty = resp.value.filter(({ account }) => Number((account as any).data.parsed.info.tokenAmount?.amount || 0) === 0);
      if (!empty.length) { toast({ title: "Nothing to close" }); setBusy(false); return; }
      let total = 0; const batch = 6; // safe size
      for (const part of chunked(empty, batch)) {
        const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash();
        const tx = withPriority(new web3.Transaction({ feePayer: wallet.publicKey!, blockhash, lastValidBlockHeight }));
        part.forEach(({ pubkey }) => tx.add(splToken.createCloseAccountInstruction(pubkey, wallet.publicKey!, wallet.publicKey!)));
        const signed = await wallet.signTransaction(tx);
        const sig = await conn.sendRawTransaction(signed.serialize());
        await conn.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, "confirmed");
        total += part.length;
      }
      setClosed(total);
      toast({ title: "Closed empty accounts", description: `${total} closed` });
    } catch (e:any) {
      toast({ title: "Close failed", description: String(e) });
    } finally { setBusy(false); }
  }, [conn, wallet.publicKey, wallet.signTransaction]);
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><BroomIcon />Close Empty Token Accounts</CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-neutral-400">{closed !== null ? (<>Closed <b>{closed}</b> accounts.</>) : (<>Safe to run periodically.</>)}
      </CardContent>
      <CardFooter>
        <Button onClick={onClose} disabled={busy}>{busy ? (<Loader2 className="mr-2 h-4 w-4 animate-spin" />) : (<XCircle className="mr-2 h-4 w-4" />)}Close 0-balance ATAs</Button>
      </CardFooter>
    </Card>
  );
}

function FreezeThawTool({ conn }: { conn: web3.Connection }) {
  const wallet = useWallet();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [mintStr, setMintStr] = useState("");
  const [ownerStr, setOwnerStr] = useState("");
  const [action, setAction] = useState<"freeze" | "thaw">("freeze");
  const onExecute = useCallback(async () => {
    if (!wallet.publicKey || !wallet.signTransaction) { toast({ title: "Connect a wallet" }); return; }
    try {
      setBusy(true);
      const mint = new web3.PublicKey(mintStr);
      const owner = new web3.PublicKey(ownerStr || wallet.publicKey!.toBase58());
      const ata = await splToken.getAssociatedTokenAddress(mint, owner, false);
      const ix = action === "freeze"
        ? splToken.createFreezeAccountInstruction(ata, mint, wallet.publicKey!)
        : splToken.createThawAccountInstruction(ata, mint, wallet.publicKey!);
      const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash();
      const tx = withPriority(new web3.Transaction({ feePayer: wallet.publicKey!, blockhash, lastValidBlockHeight }).add(ix));
      const signed = await wallet.signTransaction(tx);
      const sig = await conn.sendRawTransaction(signed.serialize());
      await conn.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, "confirmed");
      toast({ title: `${action === "freeze" ? "Frozen" : "Thawed"} account`, description: `Tx: ${sig}` });
    } catch (e:any) {
      toast({ title: "Freeze/Thaw failed", description: String(e) });
    } finally { setBusy(false); }
  }, [conn, wallet.publicKey, wallet.signTransaction, mintStr, ownerStr, action]);
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Snowflake className="h-5 w-5" />Freeze / Thaw</CardTitle>
        <CardDescription>Requires freeze authority.</CardDescription>
      </CardHeader>
      <CardContent className="grid gap-3">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div><Label>Mint</Label><Input value={mintStr} onChange={(e) => setMintStr(e.target.value)} /></div>
          <div><Label>Owner (optional)</Label><Input value={ownerStr} onChange={(e) => setOwnerStr(e.target.value)} /></div>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setAction("freeze")} className={action === "freeze" ? "bg-white/20" : ""}><Lock className="mr-2 h-4 w-4" />Freeze</Button>
          <Button onClick={() => setAction("thaw")} className={action === "thaw" ? "bg-white/20" : ""}><Unlock className="mr-2 h-4 w-4" />Thaw</Button>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={onExecute} disabled={busy || !mintStr}>{busy ? (<Loader2 className="mr-2 h-4 w-4 animate-spin" />) : action === "freeze" ? (<Lock className="mr-2 h-4 w-4" />) : (<Unlock className="mr-2 h-4 w-4" />)}{action === "freeze" ? "Freeze" : "Thaw"}</Button>
      </CardFooter>
    </Card>
  );
}

function SetAuthorityTool({ conn }: { conn: web3.Connection }) {
  const wallet = useWallet();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [mintStr, setMintStr] = useState("");
  const [target, setTarget] = useState<"mint" | "freeze">("mint");
  const [newAuthStr, setNewAuthStr] = useState("");
  const [renounce, setRenounce] = useState(false);

  const onSet = useCallback(async () => {
    if (!wallet.publicKey || !wallet.signTransaction) { toast({ title: "Connect a wallet" }); return; }
    try {
      setBusy(true);
      const mint = new web3.PublicKey(mintStr);
      const authType = target === "mint" ? splToken.AuthorityType.MintTokens : splToken.AuthorityType.FreezeAccount;
      const newAuth = renounce ? null : new web3.PublicKey(newAuthStr);
      const ix = splToken.createSetAuthorityInstruction(mint, wallet.publicKey!, authType, newAuth, []);
      const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash();
      const tx = withPriority(new web3.Transaction({ feePayer: wallet.publicKey!, blockhash, lastValidBlockHeight }).add(ix));
      const signed = await wallet.signTransaction(tx);
      const sig = await conn.sendRawTransaction(signed.serialize());
      await conn.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, "confirmed");
      toast({ title: `Set ${target} authority`, description: `Tx: ${sig}` });
    } catch (e:any) {
      toast({ title: "Set authority failed", description: String(e) });
    } finally { setBusy(false); }
  }, [conn, wallet.publicKey, wallet.signTransaction, mintStr, target, newAuthStr, renounce]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><KeyRound className="h-5 w-5" />Set Mint / Freeze Authority</CardTitle>
      </CardHeader>
      <CardContent className="grid gap-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div><Label>Mint</Label><Input value={mintStr} onChange={(e) => setMintStr(e.target.value)} /></div>
          <div>
            <Label>Authority</Label>
            <div className="flex gap-2 mt-2">
              <Button onClick={() => setTarget("mint")} className={target === "mint" ? "bg-white/20" : ""}>Mint</Button>
              <Button onClick={() => setTarget("freeze")} className={target === "freeze" ? "bg-white/20" : ""}>Freeze</Button>
            </div>
          </div>
          <div>
            <Label>New Authority (blank = renounce)</Label>
            <Input value={newAuthStr} onChange={(e) => setNewAuthStr(e.target.value)} disabled={renounce} />
            <div className="mt-2 text-xs flex items-center gap-2">
              <input type="checkbox" checked={renounce} onChange={(e) => setRenounce(e.target.checked)} />
              <Label>Renounce</Label>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={onSet} disabled={busy || !mintStr || (!renounce && !newAuthStr)}>{busy ? (<Loader2 className="mr-2 h-4 w-4 animate-spin" />) : (<KeyRound className="mr-2 h-4 w-4" />)}Set Authority</Button>
      </CardFooter>
    </Card>
  );
}

// ---- OpenBook: disabled stub to avoid build-time dependency in sandbox ----
function CancelAllOpenBookOrders({ conn }: { conn: web3.Connection }) {
  const disabled = !FEATURES.openbook;
  const [marketStr, setMarketStr] = useState("");
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><XCircle className="h-5 w-5" />Cancel All OpenBook Orders</CardTitle>
        {disabled ? (
          <CardDescription>
            Disabled in this build. Install <code>@openbook-dex/openbook</code> and set <code>FEATURES.openbook = true</code> to enable.
          </CardDescription>
        ) : (
          <CardDescription>Cancel and settle across your OpenBook markets.</CardDescription>
        )}
      </CardHeader>
      <CardContent className="grid gap-3">
        <Label>OpenBook Market ID</Label>
        <Input value={marketStr} onChange={(e) => setMarketStr(e.target.value)} placeholder="Market address" disabled={disabled} />
      </CardContent>
      <CardFooter>
        <Button disabled className="opacity-60 cursor-not-allowed"><XCircle className="mr-2 h-4 w-4"/>Unavailable</Button>
      </CardFooter>
    </Card>
  );
}

// ---- Raydium: disabled stub to avoid build-time dependency in sandbox ----
function RemoveRaydiumLiquidity({ conn }: { conn: web3.Connection }) {
  const disabled = !FEATURES.raydium;
  const [poolId, setPoolId] = useState("");
  const [pct, setPct] = useState(100);
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Coins className="h-5 w-5" />Remove Raydium Liquidity</CardTitle>
        {disabled ? (
          <CardDescription>
            Disabled in this build. Install <code>@raydium-io/raydium-sdk</code> and set <code>FEATURES.raydium = true</code> to enable.
          </CardDescription>
        ) : (
          <CardDescription>Remove LP position from a Raydium pool.</CardDescription>
        )}
      </CardHeader>
      <CardContent className="grid gap-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-2"><Label>Pool ID</Label><Input value={poolId} onChange={(e) => setPoolId(e.target.value)} disabled={disabled} /></div>
          <div><Label>Percent</Label><Input type="number" min={1} max={100} value={pct} onChange={(e) => setPct(Math.max(1, Math.min(100, parseInt(e.target.value || "100"))))} disabled={disabled} /></div>
        </div>
      </CardContent>
      <CardFooter>
        <Button disabled className="opacity-60 cursor-not-allowed"><Coins className="mr-2 h-4 w-4"/>Unavailable</Button>
      </CardFooter>
    </Card>
  );
}

function PriorityFeeHelper() {
  const [cu, setCu] = useState(300000);
  const [price, setPrice] = useState(2000); // microLamports / CU
  const lamports = calcPriorityFeeLamports(cu, price);
  const solStr = formatBaseToUiString(lamports, 9);
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><ServerCog className="h-5 w-5" />Priority Fee Helper</CardTitle>
      </CardHeader>
      <CardContent className="grid gap-3">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Compute Units</Label>
            <Input type="number" value={cu} onChange={(e) => setCu(parseInt(e.target.value || "0"))} />
          </div>
          <div>
            <Label>Price (microLamports/CU)</Label>
            <Input type="number" value={price} onChange={(e) => setPrice(parseInt(e.target.value || "0"))} />
          </div>
        </div>
        <div className="text-sm text-neutral-400">Est. Priority Fee: <b>{lamports.toString()}</b> lamports (~{solStr} SOL)</div>
      </CardContent>
    </Card>
  );
}

// CSV airdrop (UI + validation + preview + exports)
function AirdropCsvTool() {
  type Row = { addr: string; amt: string; errors?: string[] };
  const [rows, setRows] = useState<Row[]>([]);
  const [decimals, setDecimals] = useState(9);
  const [skipInvalid, setSkipInvalid] = useState(false);
  const [allowZero, setAllowZero] = useState(false);
  const [dupMode, setDupMode] = useState<'error' | 'aggregate' | 'keep-first'>('aggregate');
  const { toast } = useToast();

  const isValidSolAddress = (s: string): boolean => {
    try { new web3.PublicKey(s); return true; } catch { return false; }
  };

  const isSimpleDecimal = (s: string): boolean => {
    if (s === '') return false;
    const parts = s.split('.');
    if (parts.length > 2) return false;
    return parts.every(p => p.split('').every(ch => ch >= '0' && ch <= '9'));
  };

  const validateRow = (addr: string, amt: string, decs: number): string[] => {
    const errs: string[] = [];
    if (!isValidSolAddress(addr)) errs.push('invalid address');
    const cleaned = amt.replace(/,/g, '').trim();
    if (!isSimpleDecimal(cleaned)) errs.push('amount not numeric');
    if (cleaned === '' || Number.isNaN(Number(cleaned))) errs.push('amount missing');
    if (!errs.includes('amount not numeric') && !errs.includes('amount missing')) {
      if (Number(cleaned) < 0) errs.push('amount negative');
      if (hasExtraFraction(cleaned, decs)) errs.push(`too many decimals (>${decs})`);
    }
    return errs;
  };

  const parseUiToBase = (ui: string, decs: number): bigint => {
    return toBaseUnits(ui.replace(/,/g, '').trim(), decs);
  };

  const onFile = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]; if (!f) return;
    const text = await f.text();
    const lines = splitLines(text);
    const parsed: Row[] = [];
    for (const line of lines) {
      const parts = line.split(/,|\t/).map(s => s.trim());
      let [a, b] = parts;
      if (!a || !b) continue;
      if (/^address|wallet$/i.test(a)) continue; // skip header
      const errs = validateRow(a, b, decimals);
      parsed.push({ addr: a, amt: b, errors: errs.length ? errs : undefined });
    }
    setRows(parsed);
    const bad = parsed.filter(r => r.errors?.length);
    toast({ title: 'CSV loaded', description: `${parsed.length} rows (${parsed.length - bad.length} valid, ${bad.length} invalid)` });
  }, [toast, decimals]);

  // Derive policy-based errors (zero-amount & duplicates) without mutating original rows
  const derived = useMemo(() => {
    const out: Row[] = rows.map(r => ({ ...r, errors: r.errors ? [...r.errors] : undefined }));
    // zero-amount policy
    out.forEach(r => {
      const cleaned = r.amt.replace(/,/g, '').trim();
      if (isSimpleDecimal(cleaned)) {
        if (!allowZero && Number(cleaned) === 0) {
          (r.errors ||= []).push('zero amount not allowed');
        }
      }
    });
    // duplicate policy
    const seen = new Map<string, number>();
    out.forEach((r) => {
      const count = (seen.get(r.addr) || 0) + 1;
      seen.set(r.addr, count);
      if (dupMode === 'error' && count > 1) {
        (r.errors ||= []).push('duplicate address');
      }
    });
    return out;
  }, [rows, allowZero, dupMode]);

  const duplicatesCount = useMemo(() => {
    const map = new Map<string, number>();
    rows.forEach(r => map.set(r.addr, (map.get(r.addr) || 0) + 1));
    let dups = 0; map.forEach(v => { if (v > 1) dups += v - 1; });
    return dups;
  }, [rows]);

  const invalid = derived.filter(r => r.errors && r.errors.length > 0);
  const valid = derived.filter(r => !r.errors || r.errors.length === 0);

  // Build cleaned set according to toggles
  const cleaned = useMemo(() => {
    let base: Row[] = skipInvalid ? valid : derived;
    if (dupMode === 'aggregate') {
      const agg = new Map<string, bigint>();
      for (const r of base) {
        if (r.errors && r.errors.length) continue; // still skip errored rows in aggregate view
        const amt = parseUiToBase(r.amt, decimals);
        agg.set(r.addr, (agg.get(r.addr) || 0n) + amt);
      }
      return Array.from(agg.entries()).map(([addr, amtBig]) => ({ addr, amt: formatBaseToUiString(amtBig, decimals) } as Row));
    }
    if (dupMode === 'keep-first') {
      const seen = new Set<string>();
      const keep: Row[] = [];
      for (const r of base) {
        if (r.errors && r.errors.length) continue;
        if (seen.has(r.addr)) continue;
        seen.add(r.addr);
        keep.push({ addr: r.addr, amt: r.amt });
      }
      return keep;
    }
    // 'error' -> return only non-error rows if skipInvalid, else include all
    return base.filter(r => !r.errors || r.errors.length === 0);
  }, [derived, valid, skipInvalid, dupMode, decimals]);

  const totals = useMemo(() => {
    let recipients = 0;
    let sumBase = 0n;
    for (const r of cleaned) {
      try {
        const amt = parseUiToBase(r.amt, decimals);
        if (amt < 0) continue;
        sumBase += amt;
        recipients += 1;
      } catch {}
    }
    const sumUiStr = formatBaseToUiString(sumBase, decimals);
    return { recipients, sumBase, sumUiStr };
  }, [cleaned, decimals]);

  const canProceed = useMemo(() => {
    if (invalid.length > 0 && !skipInvalid) return false;
    if (duplicatesCount > 0 && dupMode === 'error' && !skipInvalid) return false;
    return cleaned.length > 0;
  }, [invalid.length, skipInvalid, duplicatesCount, dupMode, cleaned.length]);

  const downloadCsv = (name: string, lines: string[]) => {
    const blob = new Blob([lines.join('\\n') + '\\n'], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const onDownloadCleaned = () => {
    const lines = ['address,amount'];
    cleaned.forEach(r => lines.push(`${r.addr},${r.amt}`));
    downloadCsv('cleaned.csv', lines);
  };
  const onDownloadErrors = () => {
    const lines = ['row,address,amount,errors'];
    derived.forEach((r, i) => {
      if (r.errors && r.errors.length) lines.push(`${i + 1},${r.addr},${r.amt},"${r.errors.join(' | ')}"`);
    });
    downloadCsv('errors.csv', lines);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Upload className="h-5 w-5"/>Airdrop (CSV) — Preview</CardTitle>
        <CardDescription>
          Format: <code>address,amount</code>. Validates rows, flags errors, and can export a cleaned file. No transactions are sent.
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-2">
            <Label>Upload CSV</Label>
            <Input type="file" accept=".csv,text/csv" onChange={onFile} />
          </div>
          <div>
            <Label>Decimals</Label>
            <Input type="number" value={decimals} onChange={(e)=>setDecimals(parseInt(e.target.value||'9'))} />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="flex items-center gap-2"><input type="checkbox" checked={skipInvalid} onChange={e=>setSkipInvalid(e.target.checked)} /><Label>Skip invalid rows</Label></div>
          <div className="flex items-center gap-2"><input type="checkbox" checked={allowZero} onChange={e=>setAllowZero(e.target.checked)} /><Label>Allow zero amounts</Label></div>
          <div>
            <Label>Duplicates</Label>
            <div className="flex gap-2 mt-1">
              <Button onClick={()=>setDupMode('error')} className={dupMode==='error'? 'bg-white/20' : ''}>Error</Button>
              <Button onClick={()=>setDupMode('keep-first')} className={dupMode==='keep-first'? 'bg-white/20' : ''}>Keep first</Button>
              <Button onClick={()=>setDupMode('aggregate')} className={dupMode==='aggregate'? 'bg-white/20' : ''}>Aggregate</Button>
            </div>
          </div>
        </div>

        <div className="text-xs text-neutral-400">
          Rows: <b>{rows.length}</b> • Valid (policy-aware): <b className="text-green-400">{valid.length}</b> • Invalid: <b className="text-red-400">{invalid.length}</b> • Duplicates: <b>{duplicatesCount}</b>
        </div>

        <div className={`text-xs ${canProceed ? 'text-green-400' : 'text-red-400'}`}>
          {canProceed ? 'Ready:' : 'Blocked:'} {invalid.length} invalid{invalid.length? ', ' : ''}{duplicatesCount? `${duplicatesCount} duplicates (${dupMode})` : ''}
        </div>

        {!!derived.length && (
          <div className="max-h-72 overflow-auto text-xs bg-black/30 rounded-xl p-3 border border-white/10">
            {derived.slice(0, 300).map((r, i) => (
              <div key={i} className={`grid grid-cols-6 gap-2 rounded-lg px-2 py-1 border ${r.errors?.length ? 'bg-red-500/10 border-red-500/30' : 'border-white/10'}`}>
                <span className="col-span-3 truncate">{r.addr}</span>
                <span className="col-span-1 text-right">{r.amt}</span>
                <span className="col-span-2 text-right">{r.errors?.length ? r.errors.join(', ') : 'ok'}</span>
              </div>
            ))}
            {derived.length > 300 && <div className="mt-2 opacity-60">…and {derived.length - 300} more</div>}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-center">
          <div className="text-xs text-neutral-400">Cleaned recipients: <b>{totals.recipients}</b> • Total amount: <b>{totals.sumUiStr}</b> UI (~<b>{totals.sumBase.toString()}</b> base)</div>
          <div className="md:col-span-2 flex gap-2 justify-end">
            <Button onClick={onDownloadErrors} disabled={derived.every(r => !r.errors || r.errors.length === 0)}>Download errors.csv</Button>
            <Button onClick={onDownloadCleaned} disabled={!canProceed}>Download cleaned.csv</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ToolsGrid() {
  const { conn } = useConn();
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
      <TokenSettingsCard />
      <MintBurnTool conn={conn} />
      <FreezeThawTool conn={conn} />
      <SetAuthorityTool conn={conn} />
      <RevokeDelegates conn={conn} />
      <CloseEmptyTokenAccounts conn={conn} />
      <WSOLUnwrapper conn={conn} />
      <RemoveRaydiumLiquidity conn={conn} />
      <CancelAllOpenBookOrders conn={conn} />
      <PriorityFeeHelper />
      <AirdropCsvTool />
    </div>
  );
}

export default function App() {
  const wallets = useMemo(() => [
    new PhantomWalletAdapter(),
    new SolflareWalletAdapter(),
    new BackpackWalletAdapter(),
    new LedgerWalletAdapter(),
  ], []);

  const { endpoint } = useConn();

  return (
    <div className="min-h-screen text-white bg-gradient-to-b from-neutral-900 to-black">
      <div className="max-w-6xl mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold">Kid$ Wif Tools — Solana Utility App (lite)</h1>
        <p className="text-sm text-neutral-400 mb-4">Endpoint: {endpoint}</p>
        <ConnectionProvider endpoint={endpoint}>
          <WalletProvider wallets={wallets} autoConnect>
            <WalletModalProvider>
              <div className="mb-4"><WalletMultiButton /></div>
              <TokenConfigProvider>
                <ToolsGrid />
              </TokenConfigProvider>
            </WalletModalProvider>
          </WalletProvider>
        </ConnectionProvider>
      </div>
    </div>
  );
}
